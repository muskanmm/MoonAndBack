//
//  FriendPictureViewController.swift
//  MoonAndBack
//
//  Created by Muskan Mankikar on 9/15/23.
//

import UIKit

class FriendPictureViewController: UIViewController {

    @IBOutlet weak var heartButton: UIButton!
    @IBOutlet weak var starButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Stars background.jpg")!)
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func heartButtonPressed(_ sender: UIButton) {

        //let seconds = 0.1
//        heartButton.setBackgroundImage(UIImage(named: "heart.fill"), for: .normal)
//
//        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
//            self.heartButton.setBackgroundImage(UIImage(named: "heart"), for: .normal)
//        }
    }
    @IBAction func returnToHomeDidPress(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
