//
//  ViewController.swift
//  MoonAndBack
//
//  Created by Muskan Mankikar on 9/15/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var WishesButton: UIButton!
    
    @IBOutlet weak var StarsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        WishesButton.backgroundColor = UIColor.purple
        StarsButton.backgroundColor = UIColor.purple
        // Do any additional setup after loading the view.
    }

    
    @IBAction func wishesDidPress(_ sender: UIButton) {
        
    }
    
    @IBAction func starsDidPress(_ sender: UIButton) {
    }
    
    
}

