//
//  ViewController.swift
//  MoonAndBack
//
//  Created by Muskan Mankikar on 9/15/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var WishesButton: UIButton!
    @IBOutlet weak var StarsButton: UIButton!
    
    @IBOutlet weak var friendOneButton: UIButton!
    @IBOutlet weak var friendTwoButton: UIButton!
    @IBOutlet weak var friendThreeButton: UIButton!
    @IBOutlet weak var friendFourButton: UIButton!
    @IBOutlet weak var friendRequestButton: UIButton!
    
    
    @IBOutlet weak var myLastPictureButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        friendOneButton.isHidden = true
        friendTwoButton.isHidden = true
        friendThreeButton.isHidden = true
        friendFourButton.isHidden = true
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Stars background.jpg")!)
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func wishesDidPress(_ sender: UIButton) {
        friendOneButton.isHidden = false
        friendTwoButton.isHidden = false
        let seconds = 0.1
        WishesButton.backgroundColor = UIColor(red: 0.8784, green: 0.8784, blue: 0.8784, alpha: 0.2)
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            self.WishesButton.backgroundColor = UIColor.clear
        }
    }
    
    @IBAction func starsDidPress(_ sender: UIButton) {
        friendThreeButton.isHidden = false
        friendFourButton.isHidden = false
        let seconds = 0.1
        StarsButton.backgroundColor = UIColor(red: 0.8784, green: 0.8784, blue: 0.8784, alpha: 0.2)
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            self.StarsButton.backgroundColor = UIColor.clear
        }
    }
    
    @IBAction func friendButtonDidPress(_ sender: UIButton) {
        let seconds = 0.1
        sender.backgroundColor = UIColor(red: 0.8784, green: 0.8784, blue: 0.8784, alpha: 0.2)
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
            sender.backgroundColor = UIColor.clear
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToFriendPicture" {
            let destinationVC = segue.destination as! FriendPictureViewController
        }
        
        if segue.identifier == "goToOtherFriend" {
            let destinationVC = segue.destination as! OtherFriendPictureViewController
        }
    }
}

