//
//  SendRequestViewController.swift
//  MoonAndBack
//
//  Created by Muskan Mankikar on 9/16/23.
//

import UIKit
import UserNotifications

class SendRequestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        checkForPermission()
        // Do any additional setup after loading the view.
    }
    
    func checkForPermission(){
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.getNotificationSettings{ settings in
            switch settings.authorizationStatus {
            case .authorized:
                self.dispatchNotification()
            case .denied:
                return
            case .notDetermined:
                notificationCenter.requestAuthorization(options: [.alert, .sound]){ didAllow, error in
                    if didAllow{
                        self.dispatchNotification()
                    }
                }
            default:
                return
            }
        }
    }
    func dispatchNotification(){
        let content = UNMutableNotificationContent()
        content.title = "Anna Sent A Wish!"
        content.body = "What r u up to?"
        content.sound = .default
        content.badge = 1
        
        let notificationCenter = UNUserNotificationCenter.current()

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5.0, repeats: false)
        
        let request = UNNotificationRequest(identifier: "anna-notif", content: content, trigger: trigger)
        notificationCenter.removePendingNotificationRequests(withIdentifiers: ["anna-notif"])
        UNUserNotificationCenter.current().add(request)
    }
    
    @IBAction func sendWishReturnHomePress(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
