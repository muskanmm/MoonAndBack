//
//  MyLastPictureViewController.swift
//  MoonAndBack
//
//  Created by Muskan Mankikar on 9/16/23.
//

import UIKit

class MyLastPictureViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Stars background.jpg")!)
        // Do any additional setup after loading the view.
    }
    

    @IBAction func returnHomeDidPress(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
